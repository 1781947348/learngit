package com.phone.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Input extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */

			public static void run() {
				try {
					Input frame = new Input();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	

	/**
	 * Create the frame.
	 */
	public Input() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8BF7\u8F93\u5165\u7C7B\u522B");
		label.setBounds(10, 22, 85, 15);
		contentPane.add(label);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setBounds(140, 19, 65, 21);
		contentPane.add(comboBox);
		comboBox.addItem("");
		comboBox.addItem(" �����ֻ�");
		comboBox.addItem("�������ֻ�");
		
		JLabel label_1 = new JLabel("\u8BF7\u8F93\u5165\u4EF7\u683C");
		label_1.setBounds(0, 81, 75, 15);
		contentPane.add(label_1);
		
		
		textField = new JTextField();
		textField.setBounds(107, 78, 66, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label_2 = new JLabel("\u5230");
		label_2.setBounds(226, 81, 21, 15);
		contentPane.add(label_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(291, 78, 66, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton button = new JButton("\u53D6\u6D88");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button.setBounds(331, 229, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Output.run();
			}
		});
		button_1.setBounds(195, 229, 93, 23);
		contentPane.add(button_1);
	}
}
