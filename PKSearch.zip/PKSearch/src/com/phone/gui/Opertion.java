package com.phone.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JButton;



import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class Opertion extends JFrame {

	private JPanel contentPane;
	private JTable table;
	//public static List list;

	/**
	 * Launch the application.
	 */

			public static void run() {
				try {
					Opertion frame = new Opertion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	
	/**
	 * Create the frame.
	 */
	public Opertion() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 27, 414, 152);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{new Integer(1), new Integer(1), new Double(2000.0), "SANSUNG1"},
				{new Integer(2), new Integer(1), new Double(3000.0), "iPhone"},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"\u7F16\u53F7", "\u7C7B\u522B", "\u4EF7\u683C", "\u540D\u79F0"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Integer.class, Double.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u6765\u5230\u7BA1\u7406\u8005\u754C\u9762");
		lblNewLabel.setBounds(138, 2, 188, 15);
		contentPane.add(lblNewLabel);
		//Initialtable();
		
		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		button.setBounds(0, 229, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\u6DFB\u52A0\u4FE1\u606F");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Add.run();
			}
		});
		button_1.setBounds(201, 229, 93, 23);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("\u5220\u9664\u4FE1\u606F");
		button_2.setBounds(318, 229, 93, 23);
		contentPane.add(button_2);
	}
	

}
