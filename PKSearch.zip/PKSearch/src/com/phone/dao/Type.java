package com.phone.dao;

/**
 * Type entity. @author MyEclipse Persistence Tools
 */

public class Type implements java.io.Serializable {

	// Fields

	private Integer type;
	private String name;

	// Constructors

	/** default constructor */
	public Type() {
	}

	/** full constructor */
	public Type(Integer type, String name) {
		this.type = type;
		this.name = name;
	}

	// Property accessors

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}