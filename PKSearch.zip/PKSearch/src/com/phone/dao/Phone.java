package com.phone.dao;

/**
 * Phone entity. @author MyEclipse Persistence Tools
 */

public class Phone implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer type;
	private Double money;
	private String name;

	// Constructors

	/** default constructor */
	public Phone() {
	}

	/** full constructor */
	public Phone(Integer id, Integer type, Double money, String name) {
		this.id = id;
		this.type = type;
		this.money = money;
		this.name = name;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Double getMoney() {
		return this.money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}