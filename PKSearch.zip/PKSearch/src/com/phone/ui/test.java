package com.phone.ui;

import com.phone.dao.Phone;
import com.phone.dao.PhoneDAO;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Phone p= new Phone( 3,1, 1.2, "dsa");
		PhoneDAO a =new PhoneDAO();
		a.save(p);
	}

}
