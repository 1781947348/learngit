package com.phone.logic;

public class TypeControl {

}
