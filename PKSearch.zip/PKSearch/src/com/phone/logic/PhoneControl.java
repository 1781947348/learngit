package com.phone.logic;


import java.util.List;

import org.hibernate.Session;

import com.phone.dao.Phone;
import com.phone.factory.HibernateSessionFactory;







public class PhoneControl {

	private static PhoneControl control = null; 
	public static PhoneControl getPhoneControl(){
		if(null==control){
			control = new PhoneControl();
		}
		return control;
	}
	

	private com.phone.dao.PhoneDAO PhoneDAO = null;
	private Session session = null;
	
	private PhoneControl(){
		PhoneDAO = new com.phone.dao.PhoneDAO();
		session = HibernateSessionFactory.getSession();
	}
	

	public Phone save(int id, int type, double money,String name){
		Phone staff = new Phone(id,type , money, name);
		PhoneDAO.save(staff);
		session.beginTransaction().commit();
		session.flush();
		return staff;
	}
    
	public Phone findById(int id){
		
		try {
			Phone phone = PhoneDAO.findById(id);
			return phone;
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	
	public List findByName(String name)
	{
		try
		{
			return PhoneDAO.findByName(name);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	

	public List findByType(int type)
	{
		try
		{
			return PhoneDAO.findByType(type);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	
	public List findByMoney(double money)
	{
		try
		{
			return PhoneDAO.findByMoney(money);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	public List findALL()
	{
		return PhoneDAO.findAll();
	}
	public Boolean delete(Phone phone) {
		try {

			PhoneDAO.delete(phone);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	public Boolean merge(Phone smartphone) {
		try {

			PhoneDAO.merge(smartphone);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
}
